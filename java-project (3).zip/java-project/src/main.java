class main{
  public static void main(String[]arg){
      System.out.println("studentname=arjun");
      System.out.println("studentage=21");
      System.out.println("studentgrade=7");
      System.out.println("studen placementstates=good");
  }
}
