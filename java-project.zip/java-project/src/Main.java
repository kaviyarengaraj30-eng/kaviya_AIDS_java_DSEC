class Main {
    public static void main(String[] args) {
        System.out.println("collage:abc");
        System.out.println("dept:cse");
        System.out.println("courec:java programing");
    }
}
