class main{
  public static void main(String[]arg){
    System.out.println("name\tarjun");
    System.out.println("course\tjava");
    System.out.println("level\beginner");
    
  }
}
