class main{
  public static void main(String[]arg){
    System.out.println("java is simple");
    System.out .println("java is powerful");
  }
}
